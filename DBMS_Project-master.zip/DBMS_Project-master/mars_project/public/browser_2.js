/*
let emp_id=document.getElementById("emp_id");
let pasw_id=document.getElementById("pasw_id");

function welcome()
{
    return res.redirect('/welcome_page.html')
}

document.getElementById("create-form").addEventListener("submit",function(event){
    event.preventDefault();
    
    axios.post('/input-field',{empid: emp_id.value,passid: pasw_id.value}).then(function(res){
        welcome();
    }).catch(function(error){
        console.log("Error")
    })
    
    
})

*/